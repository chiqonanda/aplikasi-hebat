import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../app/themes/app_colors.dart';
import '../../app/themes/app_text_styles.dart';
import '../../app/themes/app_theme.dart';
import '../../controllers/kelurahan/bank_sampah_controller.dart';
import '../../core/utils/validator.dart';
import '../../core/widgets/app_widgets.dart';

class BankSampahFormView extends GetView<BankSampahController> {
  const BankSampahFormView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          controller.isEditMode ? 'Edit Bank Sampah' : 'Tambah Bank Sampah',
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: Form(
        key: controller.formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ── Informasi dasar ──────────────────────────
            _SectionCard(
              title: 'Informasi Bank Sampah',
              child: Column(
                children: [
                  AppTextField(
                    controller: controller.namaController,
                    label: 'Nama Bank Sampah *',
                    hint: 'Contoh: Bank Sampah RT 05',
                    prefixIcon: Icons.store_outlined,
                    validator: (v) =>
                        AppValidator.required(v, fieldName: 'Nama'),
                  ),
                  const SizedBox(height: 16),
                  AppTextField(
                    controller: controller.alamatController,
                    label: 'Alamat (opsional)',
                    hint: 'Masukkan alamat lengkap',
                    prefixIcon: Icons.location_on_outlined,
                    maxLines: 2,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // ── Wilayah RT/RW ────────────────────────────
            _SectionCard(
              title: 'Wilayah Cakupan',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Cakupan RT',
                    style: AppTextStyles.bodyMd.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 8),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _showRtSelectionSheet(context),
                    child: Obx(() {
                      return Container(
                        constraints: const BoxConstraints(minHeight: 52),
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant.withOpacity(0.1),
                          borderRadius:
                              BorderRadius.circular(AppTheme.radiusLg),
                          border:
                              Border.all(color: AppColors.outlineVariant),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: controller.selectedRts.isEmpty
                                  ? Text(
                                      'Pilih RT...',
                                      style: AppTextStyles.bodyLg.copyWith(
                                        color: AppColors.onSurfaceVariant
                                            .withOpacity(0.6),
                                      ),
                                    )
                                  : Wrap(
                                      spacing: 8,
                                      runSpacing: 8,
                                      children:
                                          controller.selectedRts.map((rt) {
                                        return Container(
                                          key: ValueKey('rt_chip_$rt'),
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 6),
                                          decoration: BoxDecoration(
                                            color: Colors.green.shade100,
                                            borderRadius:
                                                BorderRadius.circular(16),
                                            border: Border.all(
                                                color:
                                                    Colors.green.shade300),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                'RT $rt',
                                                style: TextStyle(
                                                  color:
                                                      Colors.green.shade800,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 13,
                                                ),
                                              ),
                                              const SizedBox(width: 6),
                                              GestureDetector(
                                                key: ValueKey(
                                                    'rt_chip_del_$rt'),
                                                behavior:
                                                    HitTestBehavior.opaque,
                                                onTap: () {
                                                  controller.selectedRts
                                                      .remove(rt);
                                                },
                                                child: Icon(
                                                  Icons.close_rounded,
                                                  size: 14,
                                                  color:
                                                      Colors.green.shade800,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      }).toList(),
                                    ),
                            ),
                            const Icon(
                              Icons.keyboard_arrow_down_rounded,
                              color: AppColors.onSurfaceVariant,
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 16),
                  AppTextField(
                    controller: controller.rwController,
                    label: 'RW (opsional)',
                    hint: 'Contoh: 02',
                    prefixIcon: Icons.home_work_outlined,
                    keyboardType: TextInputType.number,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // ── Status aktif ─────────────────────────────
            _SectionCard(
              title: 'Status',
              child: Obx(
                () => Row(
                  children: [
                    const Icon(
                      Icons.toggle_on_outlined,
                      color: AppColors.outline,
                      size: 22,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Status Aktif', style: AppTextStyles.bodyLg),
                          Text(
                            controller.isAktif.value
                                ? 'Bank sampah sedang beroperasi'
                                : 'Bank sampah tidak aktif',
                            style: AppTextStyles.bodyMd,
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: controller.isAktif.value,
                      onChanged: (v) => controller.isAktif.value = v,
                      activeColor: AppColors.primary,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Pengelola yang terhubung (edit mode) ─────
            if (controller.isEditMode)
              Obx(() {
                return Column(
                  children: [
                    _SectionCard(
                      title: 'Pengelola Terhubung',
                      child: controller.listPengelolaTerhubung.isEmpty
                          ? Row(
                              children: [
                                const Icon(
                                  Icons.person_off_outlined,
                                  color: AppColors.outline,
                                  size: 20,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  'Belum ada pengelola terhubung',
                                  style: AppTextStyles.bodyMd,
                                ),
                              ],
                            )
                          : Column(
                              children: controller.listPengelolaTerhubung
                                  .map(
                                    (p) => Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 36,
                                            height: 36,
                                            decoration: BoxDecoration(
                                              color: AppColors
                                                  .secondaryContainer,
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Icon(
                                              Icons.person_rounded,
                                              size: 18,
                                              color: AppColors
                                                  .onSecondaryContainer,
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: Text(
                                              p.namaLengkap,
                                              style: AppTextStyles.bodyLg,
                                            ),
                                          ),
                                          IconButton(
                                            icon: const Icon(
                                              Icons.link_off_rounded,
                                              size: 18,
                                              color: AppColors.error,
                                            ),
                                            onPressed: () => controller
                                                .lepaskanPengelola(p),
                                            tooltip: 'Lepas pengelola',
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                  .toList(),
                            ),
                    ),
                    const SizedBox(height: 16),
                  ],
                );
              }),

            // ── Tombol simpan ─────────────────────────────
            Obx(
              () => AppButton(
                label: controller.editData.value != null
                    ? 'Simpan Perubahan'
                    : 'Buat Bank Sampah',
                isLoading: controller.isSaving.value,
                onPressed: controller.simpan,
                icon: Icons.save_rounded,
              ),
            ),
            const SizedBox(height: 12),
            AppButton(
              label: 'Batal',
              outlined: true,
              onPressed: () => Get.back(),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  void _showRtSelectionSheet(BuildContext context) {
    final customRtController = TextEditingController();

    final defaultRts = List.generate(23, (index) {
      final num = index + 1;
      return num < 10 ? '0$num' : '$num';
    });

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            final allRts =
                {...defaultRts, ...controller.selectedRts}.toList()..sort();

            return Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                top: 16,
                left: 16,
                right: 16,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Pilih Cakupan RT',
                        style: AppTextStyles.titleLg
                            .copyWith(fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const Divider(),
                  const SizedBox(height: 12),

                  // Input RT Kustom
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: customRtController,
                          decoration: const InputDecoration(
                            hintText: 'Tambah RT kustom (misal: 05A, 21)',
                            isDense: true,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 12, vertical: 10),
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.text,
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () {
                          final val = customRtController.text.trim();
                          if (val.isNotEmpty) {
                            setState(() {
                              if (!controller.selectedRts.contains(val)) {
                                controller.selectedRts.add(val);
                                controller.selectedRts.sort();
                              }
                              customRtController.clear();
                            });
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                        ),
                        child: const Text('Tambah'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Grid of RTs
                  Container(
                    constraints: BoxConstraints(
                      maxHeight: MediaQuery.of(context).size.height * 0.45,
                    ),
                    child: SingleChildScrollView(
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: allRts.map((rt) {
                          final isSelected =
                              controller.selectedRts.contains(rt);
                          return GestureDetector(
                            key: ValueKey('rt_sheet_chip_$rt'),
                            behavior: HitTestBehavior.opaque,
                            onTap: () {
                              setState(() {
                                if (isSelected) {
                                  controller.selectedRts.remove(rt);
                                } else {
                                  controller.selectedRts.add(rt);
                                }
                                controller.selectedRts.sort();
                              });
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? Colors.green.shade100
                                    : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: isSelected
                                      ? Colors.green.shade400
                                      : Colors.grey.shade300,
                                ),
                              ),
                              child: Text(
                                'RT $rt',
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.green.shade800
                                      : Colors.black87,
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Selesai Button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        padding:
                            const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text(
                        'Selesai',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceLowest,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
        border: Border.all(color: AppColors.outlineVariant),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Text(title, style: AppTextStyles.titleMd),
          ),
          const SizedBox(height: 12),
          const Divider(height: 1),
          Padding(padding: const EdgeInsets.all(16), child: child),
        ],
      ),
    );
  }
}